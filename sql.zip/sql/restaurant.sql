-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2022 at 02:37 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(12) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `name`) VALUES
(1, 'd@gmail.com', '12345', 'Debargha Chakraborty'),
(2, 'sujoy@gmail.com', '12345', 'Sujoy Dului');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `sl` int(100) NOT NULL,
  `cus_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`sl`, `cus_id`, `pid`, `qty`, `pname`, `price`) VALUES
(18, 5, 10, 2, 'Hakka Chowmein', 150),
(19, 2, 30, 2, 'Mixed Fried Rice', 249);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cus_id` int(10) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cus_id`, `fname`, `lname`, `email`, `password`, `phone`, `address`) VALUES
(2, 'Debargha', 'Chakraborty', 'deb@gmail.com', '12345', '8777395971', 'Kolkata'),
(4, 'Tithi', 'Chowdhury', 't@gmail.com', '12345', '9786857474', 'Narendrapur'),
(5, 'Suvendu', 'Das', 's@gmail.com', '1234', '1234567890', 'Haldia'),
(6, 'Ayan', 'Karmakar', 'basu@gmail.com', '12345', '8239048119', 'Sodepur,Kolkata'),
(7, 'Rahul', 'Deb', 'r@gmail.com', '12345', '1234567890', 'Kolkata'),
(8, 'Shubham', 'Rudra', 'sr@gmail.com', '12345', '1234567890', 'Kolkata');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `pdesc` varchar(20) NOT NULL,
  `pamount` int(10) NOT NULL,
  `pdisc` int(10) NOT NULL,
  `pimg` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `pname`, `pdesc`, `pamount`, `pdisc`, `pimg`) VALUES
(8, 'Chicken Biriynai', 'Mughlai', 150, 180, 'biryani.jpg'),
(9, 'Chocolate Mousse', 'Italian', 100, 120, 'mousse.jpeg'),
(10, 'Hakka Chowmein', 'Chinese', 150, 160, 'hakka.jpg'),
(11, 'Ham Burger', 'Italian', 120, 130, 'burger.jpg'),
(13, 'Chicken Tango Pizza[6 inch]', 'Pizza', 155, 220, 'chkpizza.jpg'),
(14, 'Mutton Handi Biriyani', 'Mughlai', 220, 230, 'mutbiri.jpg'),
(15, 'Murg Shahi Korma', 'Mughlai', 210, 249, 'korma.jpg'),
(16, 'Chiken Shikh Kabab[x2]', 'Mughlai', 149, 169, 'chisik.jpg'),
(17, 'Chicken Galouti Kabab[x4 pcs]', 'Mughlai', 249, 269, 'chigal.jpg'),
(18, 'Murg Musallam', 'Mughlai', 449, 499, 'mm.jpg'),
(19, 'Chilli Chicken[x6 pcs]', 'Chinese', 149, 169, 'chilli.jpg'),
(20, 'Chilli Paneer[x8 pcs]', 'Chinese', 149, 159, 'Chpan.jpg'),
(21, 'Veg Hakka Noodles', 'Chinese', 99, 120, 'vegnood.jpg'),
(22, 'Manchow Soup', 'Chinese', 169, 199, 'mnchw.jpg'),
(23, 'McAloo Tikki Burger', 'Italian', 79, 99, 'mcalu.jpg'),
(24, 'Bengali Veg Thali', 'Bengali', 499, 549, 'bhvth.jpg'),
(25, 'Bengali Nonveg Thali', 'Bengali', 599, 649, 'bhnvth.jpg'),
(26, 'Mutton Kasha[x4 pcs]', 'Bengali', 199, 229, 'MutKa.jpg'),
(27, 'Rosogolla[x6 pcs]', 'Bengali', 49, 59, 'rsglla.jpg'),
(28, 'Bhetki Paturi[x2 pcs]', 'Bengali', 249, 269, 'vetpat.jpg'),
(29, 'Sorshe Ilish[x2 pcs]', 'Bengali', 259, 279, 'seseilis.jpg'),
(30, 'Mixed Fried Rice', 'Chinese', 249, 259, 'fri.jpg'),
(31, 'Steamed Momo[x6 pcs]', 'Chinese', 99, 110, 'momo.jpg'),
(32, 'Pan Fried Momo[x6 pcs]', 'Chinese', 129, 149, 'pmomo.jpg'),
(47, 'Mango Milk Shake[x1 glass]', 'Bengali', 130, 150, 'mngsh.jpg'),
(48, 'Chingri Malaikari[x4 pcs] ', 'Bengali', 249, 299, 'chingri.jpg'),
(49, 'Chicken Kasha[x4 pcs]', 'Bengali', 149, 169, 'chikas.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `sl` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cus_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
