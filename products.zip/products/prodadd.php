<?php error_reporting(0);
include '../connection.php';
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Products Add</title>
  <style>
    *{
      padding: 0;
      margin: 0;
      

    }
    body{
    	background-color: #000000;
    }
    .leftdiv{
      width: 30%;
      height: 100%;
      position: fixed;
      background-color:#535768;
    }
    .li{
    text-decoration: none;
    list-style: none;
    margin: 10px 50px 20px 50px;
}
.li{
  /*background-color: white;*/
  width: 300px;
  margin: 50px;
  font-size: 20px;
}
/*.li:hover{
  background-color: #fff;
}*/
.li a{
    width: 250px;
    text-decoration: none;
    color: white;
    /* font-weight: bold; */
    font-size: 30px;
    margin: 80px 50px 20px 50px; 
    border-radius: 7px;
    padding-left: 50px;
    padding-right: 50px;
    padding-top: 10px;
    padding-bottom: 10px;
    transition: all 0.3s;
}
.li a:hover{
    cursor: pointer;
    background-color: #b3b4b5;
    /*color: #00092C;*/
   /* text-decoration: underline;*/
}
    .subnav{
     display: none;
     height: 50px!important;
     width: 100%!important;
     margin-left: -55px!important;
     margin-top: 7px!important;
     margin-bottom: 50px!important;
 } 
 .products:hover .subnav{
     display: block;
     position: absolute;
     /*background:#b3b4b5 ;*/
 } 
 .subli{
    
     list-style: none;
     display: block;
 }
 .subli a{
      margin: 0px 5px 0px -25px!important;
      width: 50px !important;
      border-radius:0px!important;
      text-decoration: none!important;
      color: #fff!important;
      display:flex!important;
      font-size: 20px!important;

      
 }
 .subli a:hover{
  background: none!important;
 }
 .subnav ul{
     display: flex!important;
 }
 .picdiv{
  margin-top: 31px;
 }
 .picdiv img{
  border-radius: 50%;

 }
 .rightdiv{
 	/*z-index: 1;*/
 	/*position: relative;*/
 	/*width:70% ;*/
 	/* float: right;
 	margin-right: 393px;
 	height: 550px;
 	width: 550px;
 	margin-top: 100px;
 	border: 1px solid;
 	background-color: #8ad4b0;
   display:flex;
   justify-content:center;
   align-items:center; */
width:100%;
height:80vh;
display:flex;
justify-content:center;
align-items:center;
 }
 .inp{
 	 margin: 30px;
 	 width: 400px;
 	 height: 40px;
 	 font-size: 24px;
 	 border-radius: 10px;
 }
 .upload{
 padding:10px;
 background:transparent;
 color:white;
 width:80px;
 border:none;
 border-radius:8px;
 border:1px solid red;
 font-weight:bold;
 }
 .upload:hover{
   background:#093bd8;
   border:none;
   cursor: pointer;
   transition-duration:0.4s;
 }
 .headdiv{
 	float: right;
 	margin-right: 0px;
 	margin-left: 400px;
 	margin-top: 50px;
 	width: 70%;
 	/*z-index: 2;*/
 	position: relative;
 	
 }
 .headdiv h1{
 	color: #fff;
   display:flex;
   align-items:center;
   justify-content:center;
 }
 .back{
margin-left:20px;
 background:transparent;
 padding:6px 8px;
 color:white;
 font-weight:bold;
 border:1px solid red;
 border-radius:5px;
 }
 .back:hover{
   background:#093bd8;
   border:none;
   cursor: pointer;
   transition-duration:0.4s;
 }
.mail{
  display:flex;
  margin:5px;
  align-items:center;
}
.product{
  width:50vw;
  display:flex;
  justify-content:center;
  align-items:center;
  margin: 0 0 0 400px;
}
.item{
  /* background:aqua; */
  padding:10px;
  margin-top:30px;
  border-radius:5px;
}
input{
  background:transparent;
  outline:none;
  border:none;
  color:white;
  border-bottom:1px solid red;
}
.file{
  border:none;
  margin:auto;
  cursor: pointer;
}
.center{
  display:flex;
  justify-content:center;
  align-items:center;
  height:85vh;

}
a{
  text-decoration:none;
}
  </style>
</head>
<body>
  <div class="leftdiv">
  
  <div class="picdiv">
    <div class="mail">
    <img width="50px" height="50px" src="../images/admin.png">
    <h3 style="color:#fff; margin-left: 10px;"><?php echo $_SESSION['email']; ?></h3>
    </div><hr>
  </div>
   
  <div class="subleft">
    <div class="center">
    <ul>
      <li class="li"><a href="">HOME</a></li>
      <li class="products li"><a href="">PRODUCTS</a>

<div class="subnav">
  <ul>
    <li class="subli"><a href="">ADD</a></li>
    <li class="subli"><a href="">REMOVE</a></li>
    <li class="subli"><a href="">VIEW</a></li>
  </ul><hr>
</div>
      </li>
      <li class="li"><a href="">CUSTOMER</a></li>
      <a href="../admin_logout.php" class="back" >Logout</a>


      
      
    </ul>
  </div>
</div>
</div>
<div class="headdiv">
<h1>ADD PRODUCTS</h1>
	<hr style="width:100%;">
</div>
<div class="rightdiv">

	<form action="" method="POST" enctype="multipart/form-data">
    <div class="product">
      <div class="item">
        <input class="inp" type="text" name="pname" placeholder="Enter Products Name" required><br>
        <input class="inp" type="text" name="pdesc" placeholder="Enter Products Description" required><br>
        <input class="inp" type="text" name="pamount" placeholder="Enter Products Price" required><br>
        <input class="inp" type="text" name="poriginal" placeholder="Enter Products Original Price" required><br>
        <input class="file" type="file" name="pimg" accept="image/*" required><p>(Only jpg,jpeg,png)</p><br>
        <input class="upload" type="submit" name="upload" value="Upload">
        </div>
    </div>
	</form>


</div>
</body>
</html>

<?php

include '../connection.php';



	if(isset($_POST['upload'])){
		$pname=$_POST['pname'];
		$pdesc=$_POST['pdesc'];
		$pamount=$_POST['pamount'];
		$pdisc=$_POST['poriginal'];
		$pimg=$_FILES['pimg']['name'];
		move_uploaded_file($_FILES['pimg']['tmp_name'], "../images/".$_FILES['pimg']['name']);
		


		// $sql2="INSERT INTO products(pname,pdesc,pamount,pdisc,pimg)VALUES('$pname','$pdesc','$pamount','$pdisc','$pimg')
        $sql1 = "select * from products where  pname = '$pname'";
		$table=mysqli_query($conn,$sql1);
		  if (mysqli_num_rows($table) > 0){ 
		  	echo "<script>alert ('Error! Product allready exist');</script>";
		  }
		  else{
		  	$sql2="INSERT INTO products(pname,pdesc,pamount,pdisc,pimg)VALUES('$pname','$pdesc','$pamount','$pdisc','$pimg')";
		  	 $query = mysqli_query($conn, $sql2);
		  	 if($query){
			echo "<script>alert('successfuly uploaded');</script>"; 
		}else{
			echo "<script>alert('Error in uploaded');</script>"; 
		}

		  }
}



?>

$result1 = mysqli_query($conn, $sql1);

        if (mysqli_num_rows($result1) > 0)

